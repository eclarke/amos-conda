#ifndef CONTIG_PICKER_HH__
#define CONTIG_PICKER_HH__ 1

#include "LaunchPad.hh"

#endif
