#!/bin/sh

echo "grep $*" 1>&2

grep $*

exit 0;
